# Teradyne.FA.DIA.DAS.Listener

**DAS Message Listener for Adaptive Manufacturing Platform (AMP)**  
This .NET 8 library provides a structured framework to receive, parse, and manage DAS HTTP-based AMP messages within a test environment.

---

## ✨ Features

- Receives HTTP POST messages from AMP test cells.
- Parses messages into strongly-typed models (`AMPMessageModel`).
- Emits event-based notifications for:
  - New message received
  - Connection opened or closed
  - Errors encountered
- Automatically handles INITIALIZATION messages to configure message subscriptions.
- Returns HTTP responses with message state or error info.

---

## 📦 Classes Overview

| Class | Description |
|-------|-------------|
| `DASMessageListener` | Manages HTTP listener lifecycle and dispatches requests to the processor |
| `AMPMessageProcessor` | Parses incoming requests and invokes the appropriate business logic |
| `AMPMessageModel` | Represents a structured AMP message with metadata and JSON formatting |
| `AMPMessageManager` | Maintains message list and subscription state |
| `AMPEvents` | Contains the delegate definitions for AMP event handling |

---

## 💡 Example Usage

```csharp


DASMessageListener listener = new DASMessageListener("http://localhost:8080/AMP/");

listener.Connected += () => Console.WriteLine("Connected to DAS.");
listener.Disconnected += () => Console.WriteLine("Disconnected.");
listener.Error += (ex) => Console.WriteLine($"Error: {ex.Message}");
listener.NewMessage += (cellid, message) => 
{
    Console.WriteLine($"New message from {cellid}: {message.MessageName}");
};

await listener.Start();
```

---

## 🔧 Requirements

- .NET 8
- Serilog (>= 4.2.0)
- Newtonsoft.Json (>= 13.0.3)
- Teradyne.FA.DIA.Utils

---

## 📜 License

MIT (c) Teradyne DIA